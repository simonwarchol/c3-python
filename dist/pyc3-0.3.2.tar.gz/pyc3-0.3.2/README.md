Python implementation of Jeff Heer's C3 color naming model,
outlined in

```bibtex
Jeffrey Heer and Maureen Stone. 2012. 
Color naming models for color selection, image editing and palette design. 
In Proceedings of the SIGCHI Conference on Human Factors in Computing Systems (CHI '12). 
Association for Computing Machinery, New York, NY, USA, 1007â1016. 
https://doi-org.ezp-prod1.hul.harvard.edu/10.1145/2207676.2208547
```

