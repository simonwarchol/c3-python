# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['c3_python']

package_data = \
{'': ['*'], 'c3_python': ['data/xkcd/*']}

install_requires = \
['colorio>=0.12.15,<0.13.0', 'numpy>=1.24.2,<2.0.0']

setup_kwargs = {
    'name': 'c3-python',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Simon Warchol',
    'author_email': 'simonwarchol@g.harvard.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
